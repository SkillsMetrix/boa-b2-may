
from fastapi import FastAPI,HTTPException,status,APIRouter
router= APIRouter(tags=["BOA Read APP"])

userData=[]

# reused search the user with specific ID
def searchUser(id):
    for i,v in enumerate(userData):
        if v['id']== id:
            return i

# get function which uses loadusers to load the userdata
@router.get("/loadusers")
def loadusers():
    return {'message':userData}

# search the user
@router.get("/loaduser/{id}")
def findUser(id:int):
    data=searchUser(id)
    if data ==None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Given ID not found')
    return {"User Details ": data}




    





from fastapi import FastAPI
from . import crudapp,readapp,models
from . database import engine

models.Base.metadata.create_all(bind=engine)

app= FastAPI()

app.include_router(crudapp.router)
app.include_router(readapp.router)
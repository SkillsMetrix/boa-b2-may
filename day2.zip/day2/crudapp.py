
from fastapi import HTTPException,status,APIRouter,Depends
from . import schema,models
from .database import engine,get_connection
from sqlalchemy.orm import Session

router= APIRouter(tags=["BOA DML APP"])

userData=[]

# reused search the user with specific ID
def searchUser(id):
    for i,v in enumerate(userData):
        if v['id']== id:
            return i
# delete data
@router.delete("/deleteuser/{id}")
def deleteUser(id:int):
    data=searchUser(id)
    if data ==None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Given ID not found')
    userData.pop(data)
    return {"User Deleted ": data}

# update

@router.put("/updateuser/{id}")
def updateUser(id:int,udata:schema.User):
    data=searchUser(id)
    if data ==None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Given ID not found')
    post=udata.model_dump()
    post['id']=id
    userData[data]=post
    return {"User updated ": data}

# add function which uses adduser to add in the userdata
@router.post("/adduser",status_code=status.HTTP_201_CREATED)
def addUser(udata:schema.User,db:Session=Depends(get_connection)):

    data= models.UserApp(**udata.model_dump())
    db.add(data)
    db.commit()
    return {"user details":data}
    





print('welcome to python training...!')

name='Amarjeet'
city='pune'
pin=989898
state='MH'
mobile=99999999

print(f"My Name is {name} , my city is : {city} with pincode: {pin}")
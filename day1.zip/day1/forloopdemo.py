
# declare array
userName=['admin','manager','qa']


for uname in userName:
    print(uname)


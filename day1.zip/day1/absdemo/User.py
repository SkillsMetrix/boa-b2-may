class User():
    name=''
    email=''
    #constructor
    def __init__(self,name,email):
        self.name=name
        self.email=email
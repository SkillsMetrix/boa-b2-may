
def showWelcome():
    print('welcome to function')

def calculate(x,y):
    return x+y

showWelcome()

result= calculate(12,13)
print(result)